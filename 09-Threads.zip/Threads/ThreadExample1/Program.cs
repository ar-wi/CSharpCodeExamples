﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadExample1
{
    class Program
    {
        volatile static bool toRun = true;
        private static void runA()
        {
            while (toRun)
            {
                Console.WriteLine("A");
                Thread.Sleep(1000);
            }
        }

        static void Main(string[] args)
        {
            Thread thread = new Thread(runA); 
            thread.Start();
            Thread.Sleep(3000);
            toRun = false;
        }
    }
}
