﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex7
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 100000;
            Console.WriteLine("{0} ", x);
            Console.WriteLine("{0:n} ", x);
        }
    }
}
