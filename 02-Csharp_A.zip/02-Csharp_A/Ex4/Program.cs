﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex4
{
    class Program
    {
        static void Main(string[] args)
        {
            string userName = "Aryeh", greeting ="Good afternoon";
            DateTime now = DateTime.Now;
            //Console.WriteLine("{1}, {0} it's {2} now", userName, greeting, now);

            string s = string.Format("{1}, {0} it's {2} now", userName, greeting, now);

            int age;
            bool res;
            do {
                Console.WriteLine("Enter age");
                res = int.TryParse(Console.ReadLine(), out age);
                if (!res)
                    Console.WriteLine("Wrong input");
            } while (!res);

            Console.WriteLine("Your age is {0}", age);


            Console.WriteLine(s);
        }
    }
}
