﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex6
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 2;
            int y = 8;
            int money = 8888888;
            Console.WriteLine("{0:0.0} + {1:e} = 0x{2:X} and this {3:N}", x, y, x + y,money);
        }
    }
}
