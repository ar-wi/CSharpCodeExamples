﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine(@"C:\Program Files\Microsoft Visual Studio 10.0");
            Console.WriteLine(@" 
                            *
                          *   *
                         *******
                        ");
        }
    }
}
