﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter your name:");
            string userName = Console.ReadLine();
            Console.WriteLine("hello " + userName);
            
        }
    }
}
