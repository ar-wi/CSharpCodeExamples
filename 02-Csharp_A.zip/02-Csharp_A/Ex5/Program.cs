﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int x = 2;
            int y = 3;
            Console.WriteLine("{0} + {1} = {2} " , x, y, x + y);
        }
    }
}
