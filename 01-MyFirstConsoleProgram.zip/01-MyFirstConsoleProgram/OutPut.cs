﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFirstConsoleProgram
{
    class OutPut
    {
        public static int Main()
        {
            //Console.WriteLine("Hello world, enter a number");
            //int num = int.Parse(Console.ReadLine());
            //Console.WriteLine("the number is: {0}",num);
            //Console.WriteLine("num is: " + num);

            //int [] arr = new int[30];
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    arr[i] = i;
            //    Console.WriteLine("arr[{0}] = {1}",i,arr[i]);
            //}

            string[] strArr = new string[4];
            strArr[0] = "rachel";
            strArr[1] = "sara";
            strArr[2] = "rivka";
            strArr[3] = "leah";
            //for (int i = 0; i < strArr.Length; i++)
            //{
            //    Console.WriteLine("arr[{0}] = {1}",i,strArr[i]);
            //}
            foreach (string str in strArr)
                Console.WriteLine(str);
            return 0;

        }
        class Adina
        {
            
        }
    }
}
