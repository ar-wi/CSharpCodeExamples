﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyFirstConsoleProgram
{
    class Output
    {
        public static int Main()
        {
            Console.WriteLine("Hello, world!");
            Console.Write("Enter a number: ");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("the number is: {0}", num);
            Console.WriteLine("num is: " + num);

            Console.Write("Enter array size: ");
            int size = int.Parse(Console.ReadLine());

            int[] arr = new int[size];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = num + i;
                Console.WriteLine("arr[{0}] = {1}", i, arr[i]);
            }

            string[] strArr = new string[4];
            strArr[0] = "Sara";
            strArr[1] = "Rivka";
            strArr[2] = "Rachel";
            strArr[3] = "Leah";

            Console.WriteLine("\nString Array Before Sorting:");

            for (int i = 0; i < strArr.Length; i++)
            {
                Console.WriteLine("arr[{0}] = {1}", i, strArr[i]);
            }

            Array.Sort(strArr);

            Console.WriteLine("\nString Array After Sorting:");

            for (int i = 0; i < strArr.Length; i++)
            {
                Console.WriteLine("arr[{0}] = {1}", i, strArr[i]);
            }


            Console.WriteLine("\nforeach Loop:");

            foreach (string str in strArr)
                Console.WriteLine(str);

            return 0;
        }
    }
}
