﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enums
{
    public enum Family { Abba, Ema, Ben1, Ben2, Bat1, NumberPeople }
    public enum Food { steak, chocolate, pizza, bread, ice_cream }

    class FirstProgram
    {
        static void Main(string[] args)
        {
            Food[] favorites = new Food[(int)Family.NumberPeople];
            favorites[(int)Family.Abba] = Food.steak;
            for (int i = 0; i < favorites.Length; i++)
                favorites[i] = (Food)i;

            foreach (Food f in favorites)
                Console.WriteLine("{0} is favorite of {1} ", f, (Family)(int)f);

            Console.WriteLine();

            foreach (Food f in favorites)
            {
                int num = (int)f;
                Family fm = (Family)num;
                Console.WriteLine("{0} is favorite of {1} ", f, fm);
            }
        }


    }
}
