﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex92
{
    class Program
    {
        static void Main(string[] args)
        {

            DateTime d1 = DateTime.Now;
            d1.ToStringProperty();
        }
    }
}
