﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex6
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = 8;
            var str = "oshri";
            Console.WriteLine(x);
            Console.WriteLine(str);

        }
    }
}
