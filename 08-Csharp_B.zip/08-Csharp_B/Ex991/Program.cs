﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex991
{
    class Program
    {
        static void Main(string[] args)
        {
            dynamic d = "oshri";
            Console.WriteLine(d);
            d += 123;
            Console.WriteLine(d);
        }
    }
}
