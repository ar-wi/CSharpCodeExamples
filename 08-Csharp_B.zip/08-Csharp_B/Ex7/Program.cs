﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex7
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = 8;
            var m = new { ID = 34, Name = "oshri", Age = 30 };
           
            Console.WriteLine(m.Age);
        
        }
    }
}
