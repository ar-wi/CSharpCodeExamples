﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex8
{
    class Program
    {

        static void Main(string[] args)
        {
            int[] arr = new int[] { 2, 34, 56, 7 };

            //foreach (int item in arr)
            //    Console.WriteLine(item);
            foreach (int item in arr)
            {
                Console.WriteLine(item);
            }
           
          
        }
    }
}
