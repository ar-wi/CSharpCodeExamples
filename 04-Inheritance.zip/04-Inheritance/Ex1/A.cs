﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex1
{
    class A
    {
        private int x;
        private int y;

        public A()
        {
            Console.WriteLine("run A()");
        }
    }

}
